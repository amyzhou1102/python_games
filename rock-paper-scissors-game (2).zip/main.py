import random

while True:
  #printing the choices
    player_action = input("Enter a choice (rock, paper, scissors): ")
    available_actions = ["rock", "paper", "scissors"]
    computer_action = random.choice(available_actions)
    print(f"\nYou chose {player_action}, computer chose {computer_action}.\n")
#
    if player_action == computer_action:
        print(f"Both players selected {player_action}. It's a tie!")
    elif player_action == "rock":
        if computer_action == "scissors":
            print("Rock smashes scissors! You win! Congrats! Woohoo!")
        else:
            print("Paper covers rock! You lose. You suck lol.")
    elif player_action == "paper":
        if computer_action == "rock":
            print("Paper covers rock! You win! YAYY!!!")
        else:
            print("Scissors cuts the paper! You lose. be smarter next time buddy.")
    elif player_action == "scissors":
        if computer_action == "paper":
            print("Scissors cuts paper! You win! Nice brain. ALbert Einstein 2.0! ")
        else:
            print("Rock smashes scissors! You lose. Did you lose your brain cells?")

    play_again = input("Play again? (yes/no): ")
    if play_again.lower() != "yes":
      print ("the game is ending. bye bye. have a nice day :)")
      break