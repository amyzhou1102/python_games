import random

easywordlist = [
  'panda',
  'market',
  'letter',
  'everyday',
  'tomato',
  'cat',
  'dog',
  'happy',
  'silly',
  'snake',
  'piano',
  'cello',
  'harp',
  'sad',
  'fries'
]

mediumwordlist = [
  "teacher",
  "aligator",
  "tommorow"
  "orchestra",
  "giraffe",
  "difficulty",
  'hamburger',
  "steak",
  "available",
  'dentist',
  'hospital'
]

hardwordlist = [
  "weird",
  'intelligence',
  'pronounciation',
  'hankerchief',
  'psychologist'
  'Asthma',
  "unbelievable",
  'circle',
  'disappear'
]
def display_hangman(tries):
    stages = [  # final state: head, torso, both arms, and both legs
                """
                   --------
                   |      |
                   |      O
                   |     \\|/
                   |      |
                   |     / \\
                   -
                """,
                # head, torso, both arms, and one leg
                """
                   --------
                   |      |
                   |      O
                   |     \\|/
                   |      |
                   |     / 
                   -
                """,
                # head, torso, and both arms
                """
                   --------
                   |      |
                   |      O
                   |     \\|/
                   |      |
                   |      
                   -
                """,
                # head, torso, and one arm
                """
                   --------
                   |      |
                   |      O
                   |     \\|
                   |      |
                   |     
                   -
                """,
                # head and torso
                """
                   --------
                   |      |
                   |      O
                   |      |
                   |      |
                   |     
                   -
                """,
                # head
                """
                   --------
                   |      |
                   |      O
                   |    
                   |      
                   |     
                   -
                """,
                # initial empty state
                """
                   --------
                   |      |
                   |      
                   |    
                   |      
                   |     
                   -
                """
    ]
    return stages[tries]
def easy_mode():
  word = random.choice(easywordlist)
  return word.upper ()

def medium_mode():
  word = random.choice(mediumwordlist)
  return word.upper ()

def hard_mode():
  word = random.choice(hardwordlist)
  return word.upper ()
  
def play(word):
  word_complete = "_" * len(word)
  guessed = False
  guessed_letters = []
  guessed_words = []
  tries= 6
  print("Play Hangman!")
  print (display_hangman(tries))
  print (word_complete)
  print("\n")
  while not guessed and tries > 0:
    guess = input ("Guess a letter or word: ").upper()
    if len(guess) == 1 and guess.isalpha():
      if guess in guessed_letters:
        print ("you've guessed this letter already!")
      elif guess not in word:
        print (guess, "is not in the word.")
        tries-=1
        guessed_letters.append(guess)
      else:
        print ("Yay! You guessed a correct letter!", guess, "is in the word!")
        guessed_letters.append(guess)
        wordaslist = list(word_complete)
        indices = [i for i, letter in enumerate(word) if letter == guess]
        for index in indices:
          wordaslist[index] = guess
        word_complete = "".join(wordaslist)
        if "_" not in word_complete:
          guessed = True
          

    elif len(guess) == len(word) and guess.isalpha():
      if guess in guessed_words:
        print ("You already guessed the word")
      elif guess != word:
        print ("Oh no!", guess, "is not the word")
        tries -= 1
        guessed_words.append(guess)
      else:
        guessed = True
        word_complete = word
    else:
        print("Your guess is not valid.")
    print(display_hangman(tries))
    print(word_complete)
    print("\n")
  if guessed:
    print ("Hooray!, you guessed the word!!")
  else:
    print ("Oops, you ran out of tries, try better next time!", "The word was", word, ".")


choice_difficulty = input("choose the difficulty of the word, easy, medium, or hard :   ")

if choice_difficulty=="easy":
  play(easy_mode ())
  
elif choice_difficulty=="medium":
 
  play(medium_mode())
  
else:
  play(hard_mode())
  

